package com.virtusa.virtusaforum.controllers;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.virtusa.virtusaforum.models.User;
import com.virtusa.virtusaforum.services.UserServices;


@Controller
@SessionAttributes("userId")
public class LoginController {
	
	
	@Autowired
	HttpSession httpSession;
	@Autowired
	private UserServices userService;
	private static final Logger log=LogManager.getLogger(LoginController.class);
	@GetMapping("/login")
	public String login()
	{
		return "login";
	}
	@PostMapping("/login")
	public String login(@ModelAttribute User user,Model model)
	{
		String pass=user.getPassword();
		int userId=user.getUserId();
		
		User user1=userService.getUser(userId);
		if(user1.getPassword().equals(pass))
		{
			httpSession.setAttribute("userId", userId);
			model.addAttribute("userId",userId);
			log.info("logged in successfully");
			return "userhome";
		}
		else
		{
			return "home";
		}
		
	}
}
