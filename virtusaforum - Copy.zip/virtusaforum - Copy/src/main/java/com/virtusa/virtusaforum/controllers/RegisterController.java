package com.virtusa.virtusaforum.controllers;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.virtusa.virtusaforum.models.User;
import com.virtusa.virtusaforum.services.UserServices;

@Controller
public class RegisterController {
	@Autowired
	private UserServices userService;
	private static final Logger log=LogManager.getLogger(RegisterController.class);
	@GetMapping("/registration")
	public String registration()
	{
		return "registration";
	}
	
	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute User user, Model model)
	{
		
		model.addAttribute("user", userService.saveUser(user));	
		log.info("info log in our saveusermethod");
		return "home";
	}
	

}
