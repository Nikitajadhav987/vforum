package com.virtusa.virtusaforum.repository;


import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.virtusaforum.models.Answer;
import com.virtusa.virtusaforum.models.Question;

public interface QuestionRepository extends JpaRepository<Question,Integer>{
	 // @Modifying
     // @Transactional // Make sure to import org.springframework.transaction.annotation.Transactional
     /// public void deleteByCreatedOnBefore(Date expiryDate);
	  
	  @Query("select q from Question q where q.created <=:expiryDate")
	  List<Question> deleteByCreatedOnBefore(@Param("expiryDate") Date expiryDate);

}
