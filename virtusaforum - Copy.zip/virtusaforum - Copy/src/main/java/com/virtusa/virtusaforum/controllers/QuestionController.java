package com.virtusa.virtusaforum.controllers;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.virtusa.virtusaforum.models.Question;
import com.virtusa.virtusaforum.services.QuestionService;
@Controller
@SessionAttributes("userId")

public class QuestionController {
	@Autowired
	private QuestionService questionService;
	private static final Logger log=LogManager.getLogger(QuestionController.class);
	@GetMapping("/question")
	public String question()
	{
		return "question";
	}
	@PostMapping("/saveQuestion")
	public String saveQuestion(@RequestParam String question, Model model,@ModelAttribute("userId") int userId)
	{
		
		model.addAttribute("question",questionService.saveQuestion(question,userId));		
		log.info("question posted sucessfully");
		return "question";
	}
	@RequestMapping("/viewquestion")
	public String listQuestion(Model model)
	{
		List<Question> listQuestion=questionService.getAllQuestions();
		model.addAttribute("listQuestion",listQuestion);
		return "viewquestion";
	}
	public Question getQuestionByUserId(@ModelAttribute("userId") int userId)
	{
		return questionService.getQuestionByUserId(userId);
	}
	
	@PostMapping("/addquestion")
	public String addQuestion(@RequestParam MultipartFile imageURL) {
		questionService.uploadFile(imageURL);
		return "viewquestion";
				
	}
}
