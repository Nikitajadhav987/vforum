package com.virtusa.virtusaforum.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.virtusa.virtusaforum.models.Answer;
import com.virtusa.virtusaforum.models.Question;
import com.virtusa.virtusaforum.models.User;
import com.virtusa.virtusaforum.repository.AnswerRepository;
@Service
public class AnswerService {
	@Autowired
	private AnswerRepository answerRepo;
	@Autowired
	private UserServices userService;
	@Autowired
	private QuestionService questionService;
	public Answer saveAnswer(String answer,int questionId,int userId)
	{
		Answer newAnswer=new Answer();
		newAnswer.setAnswer(answer);
		User user=userService.getUserByUserId(userId);
		Question question=questionService.getQuestionById(questionId);
		newAnswer.setUser(user);
		newAnswer.setQuestion(question);
		return answerRepo.save(newAnswer);
	}
	public List<Answer> getAllAnswers()
	{
		List<Answer> answer =answerRepo.findAll();
		System.out.println(answer.size());
		return answer;
	}
	public List<Answer> getAnswerByQuestion(int questionId)
	{
		return answerRepo.getAnswersByQuestion(questionId);
	}
	
}

