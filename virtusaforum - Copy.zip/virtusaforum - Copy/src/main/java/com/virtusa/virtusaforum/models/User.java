package com.virtusa.virtusaforum.models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "UsersTable")
@Inheritance(strategy = InheritanceType.JOINED)
public class User {
	@Id
	@Column(name = "UserId", length = 10, nullable = false)
	private int userId;
	@Column(name = "UserName", length = 50)
	private String userName;
	@Column(name = "EmailId", length = 50)
	private String emailId;
	@Column(name = "MobileNumber", length = 50)
	private long mobileNumber;
	@Column(name = "Location", length = 50)
	private String location;
	@Column(name = "Designation", length = 50)
	private String designation;
	@Column(name = "Password", length = 20)
	private String password;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
