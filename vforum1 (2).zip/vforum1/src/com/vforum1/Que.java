package com.vforum1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Que
 */

public class Que extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
  

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		try{  
			if(request.getParameter("login")!=null)
			{
			 
			 String id=request.getParameter("id");
			 String que= request.getParameter("question");
			  
	    	Class.forName("oracle.jdbc.driver.OracleDriver");  
	    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","bes","123");  
	    	PreparedStatement st= con.prepareStatement("insert into Ques values(?,?)");
			st.setString(1,id);
			st.setString(2, que);
		
	    	st.executeUpdate();
	    	PrintWriter out=response.getWriter();
			out.println("succeed");
			}
	    	          
	    	}
			catch(Exception e)
			{
				System.out.println(e);
			}
		
    }
}