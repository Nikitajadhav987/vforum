package com.vforum1;
import java.io.*;

import java.util.*;

import java.sql.*;

import javax.servlet.*;

import javax.servlet.http.*;



public class Health extends HttpServlet{



  private ServletConfig config;

  //Setting JSP page

  



  public void init(ServletConfig config)

  throws ServletException{

 this.config=config;

 }

  public void doGet(HttpServletRequest request, HttpServletResponse response)

    throws ServletException,IOException
{

  

  PrintWriter out = response.getWriter();

  //Establish connection to MySQL database

  String connectionURL;

  Connection connection
= null;

  ResultSet rs;

  response.setContentType("text/html");

  List dataList
= new ArrayList(); 

  try {

 // Load the database driver

  Class.forName("oracle.jdbc.driver.OracleDriver");

  // Get a Connection to the database

  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","k11", "k11"); 

  //Select the data from the database

  String sql = "select * from Que2";

  Statement s = connection.createStatement();

  s.executeQuery (sql);

  rs = s.getResultSet();

  while (rs.next ()){

  //Add records into data list


dataList.add(rs.getString("question"));

dataList.add(rs.getString("answer"));
  }

  rs.close ();

  s.close ();

  }catch(Exception e){

  System.out.println("Exception is ;"+e);

  }

  request.setAttribute("data",dataList);

  //Disptching request

  RequestDispatcher dispatcher = request.getRequestDispatcher("Health.jsp");

  if (dispatcher != null){

  dispatcher.forward(request, response);

  } 

  }

}